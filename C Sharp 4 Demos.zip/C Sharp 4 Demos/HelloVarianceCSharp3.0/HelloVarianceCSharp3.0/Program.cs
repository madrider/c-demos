﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelloVarianceCSharp3._0
{
    class Program
    {
        static void Main(string[] args)
        {
            //The Co-Variant arrays of .NET was an issue. 
            //The following code will compile but throw exception at runtime.

            Employee emp = new Manager();
            //emp.EmployeeId = 101;

            //Console.WriteLine(emp.EmployeeId);

            Employee[] employees = new Manager[10];
            Employee e = new Employee();
            Manager m = new Manager();

            //try
            //{
            //    employees[0] = m;

            //    employees[1] = m;
            //    employees[2] = m;

            //    foreach (Employee em in employees)
            //        Console.WriteLine(em.EmployeeId);
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}


            //The issus here is Code that compiles without errors throws type exceptions at runtime , so when Generics were
            // introduced, Microsoft resolved this and and made Generics invariant

            List<Employee> emplist = new List<Employee>();
            ////This will work fine as we can be sure Manager has all Employees's properties
            emplist.Add(new Manager());

            List<Manager> managerlist = new List<Manager>();
            //////This will not compile
            //managerlist.Add(new Employee());

            IList<Manager> imanagers = new List<Manager>();
            imanagers.Add(new Manager() { EmployeeId = 101 });
            imanagers.Add(new Manager() { EmployeeId = 102 });
            imanagers.Add(new Manager() { EmployeeId = 103 });


            //Not Allowed in .NET Framework 3.0 & 3.5
            //IEnumerable<Employee> iemployees = imanagers;

            //foreach (Manager mgr in iemployees)
            //    Console.WriteLine(mgr.EmployeeId);

            Console.ReadKey();

        }
        public class Employee
        {
            public int EmployeeId { get; set; }
            public void Display()
            {
                Console.WriteLine("Employee");
            }
        }
        public class Manager : Employee
        {
            public double Perks { get; set; }
            public void Display()
            {
                Console.WriteLine("Manager");
            }
        }

    }
}
