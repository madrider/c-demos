﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Variance_vs2008
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public int DepartmentId { get; set; }
        public Employee()
        {
        }
        public Employee(int eid, int deptid)
        {
            EmployeeId = eid;
            DepartmentId = deptid;
        }
    }
    public class Manager : Employee
    {
        public double Perks { get; set; }
        public Manager()
        {
        }
        public Manager(int eid, int deptid, double perks)
            : base(eid, deptid)
        {
            Perks = perks;
        }
    }
}
