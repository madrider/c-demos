﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;

namespace HelloParallel
{
    public class StockQuote
    {
        public int ID { get; set; }
        public string Company { get; set; }
        public decimal Price { get; set; }
    }

    public class StockService
    {
        public static decimal CallService(StockQuote Quote)
        {
            Console.WriteLine("Executing long task for {0}", Quote.Company);
            var rand = new Random(DateTime.Now.Millisecond);
            System.Threading.Thread.Sleep(1000);
            return Convert.ToDecimal(rand.NextDouble());
        }
    }

    class Program
    {
        public static List<StockQuote> Stocks = new List<StockQuote>();
        static void Main(string[] args)
        {
            double serialSeconds = 0;
            double parallelSeconds = 0;

            Stopwatch sw = new Stopwatch();

            PopulateStockList();

            sw = Stopwatch.StartNew();
            RunInSerial();
            serialSeconds = sw.Elapsed.TotalSeconds;

            sw = Stopwatch.StartNew();
            RunInParallel();
            parallelSeconds = sw.Elapsed.TotalSeconds;

            Console.WriteLine("Finished serial at {0} and took {1}", DateTime.Now, serialSeconds);
            Console.WriteLine("Finished parallel at {0} and took {1}", DateTime.Now, parallelSeconds);
            Console.ReadLine();

        }
        private static void RunInParallel()
        {
            Parallel.For(0, Stocks.Count, i =>
            {
                Console.WriteLine("Parallel processing stock: {0}", Stocks[i].Company);
                StockService.CallService(Stocks[i]);
                Console.WriteLine();
            });
        }

        private static void RunInSerial()
        {
            for (int i = 0; i < Stocks.Count; i++)
            {
                Console.WriteLine("Serial processing stock: {0}", Stocks[i].Company);
                StockService.CallService(Stocks[i]);
                Console.WriteLine();
            }
        }

        private static void PopulateStockList()
        {
            Stocks.Add(new StockQuote { ID = 1, Company = "Microsoft", Price = 5.34m });
            Stocks.Add(new StockQuote { ID = 2, Company = "IBM", Price = 1.9m });
            Stocks.Add(new StockQuote { ID = 3, Company = "Yahoo", Price = 2.34m });
            Stocks.Add(new StockQuote { ID = 4, Company = "Google", Price = 1.54m });
            Stocks.Add(new StockQuote { ID = 5, Company = "Altavista", Price = 4.74m });
            Stocks.Add(new StockQuote { ID = 6, Company = "Ask", Price = 3.21m });
            Stocks.Add(new StockQuote { ID = 7, Company = "Amazon", Price = 20.8m });
            Stocks.Add(new StockQuote { ID = 8, Company = "HSBC", Price = 54.6m });
            Stocks.Add(new StockQuote { ID = 9, Company = "Barclays", Price = 23.2m });
            Stocks.Add(new StockQuote { ID = 10, Company = "Gilette", Price = 1.84m });
        }
    }
}
